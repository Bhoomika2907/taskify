import api from './api';
import type { Comment, CreateCommentPayload } from './types';

export const commentService = {
  getByTask: (taskId: number): Promise<Comment[]> =>
    api.get(`/comments/task/${taskId}/`).then(r => r.data),

  create: (payload: CreateCommentPayload): Promise<Comment> =>
    api.post('/comments/add/', payload).then(r => r.data),
};