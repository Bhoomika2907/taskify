import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';
import {
  ArrowLeft, Plus, X, MessageSquare, Send, ChevronRight,
  Calendar, Circle, CheckCircle2, Loader2
} from 'lucide-react';
import { format } from 'date-fns';

import type { Task, TaskStatus, Project, ProjectMember, Comment } from '../services/types';
import { projectService } from '../services/projectService';
import { taskService } from '../services/taskService';
import { commentService } from '../services/commentService';
import { authService } from '../services/authservice';

const COLUMNS: { key: TaskStatus; label: string; color: string; bg: string; dot: string }[] = [
  { key: 'todo',        label: 'To Do',      color: '#6B7280', bg: '#F3F4F6', dot: '#9CA3AF' },
  { key: 'in_progress', label: 'In Progress', color: '#D97706', bg: '#FFFBEB', dot: '#F59E0B' },
  { key: 'completed',   label: 'Completed',   color: '#059669', bg: '#ECFDF5', dot: '#10B981' },
];

const NEXT_STATUS: Record<TaskStatus, TaskStatus | null> = {
  todo: 'in_progress',
  in_progress: 'completed',
  completed: null,
};

const STATUS_LABEL: Record<TaskStatus, string> = {
  todo: 'Start',
  in_progress: 'Complete',
  completed: 'Done',
};

const CommentPanel = ({ task, user, onClose }: { task: Task; user: any; onClose: () => void }) => {
  const [comments, setComments] = useState<Comment[]>([]);
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);

  useEffect(() => {
    commentService.getByTask(task.id)
      .then(setComments)
      .catch(() => toast.error('Could not load comments'))
      .finally(() => setLoading(false));
  }, [task.id]);

  const send = async () => {
    if (!text.trim()) return;
    setSending(true);
    try {
      const comment = await commentService.create({ task: task.id, text });
      setComments(prev => [...prev, { ...comment, user_name: user?.name }]);
      setText('');
    } catch {
      toast.error('Failed to send comment');
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="mt-2 border border-gray-200 rounded-2xl overflow-hidden bg-white shadow-sm">
      <div className="flex items-center justify-between px-4 py-2 border-b border-gray-100 bg-gray-50">
        <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider flex items-center gap-1.5">
          <MessageSquare className="w-3.5 h-3.5" /> {task.name}
        </span>
        <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><X className="w-4 h-4" /></button>
      </div>
      <div className="max-h-52 overflow-y-auto px-4 py-3 space-y-3">
        {loading ? <Loader2 className="w-4 h-4 animate-spin mx-auto text-gray-300" /> : 
          comments.map((c, i) => (
            <div key={c.id || i} className="flex gap-2.5">
              <div className="w-6 h-6 rounded-full bg-black text-white flex items-center justify-center text-[10px] font-bold">
                {(c.user_name || 'U').charAt(0).toUpperCase()}
              </div>
              <div>
                <div className="flex items-baseline gap-2">
                  <span className="text-xs font-semibold">{c.user_name || 'User'}</span>
                  <span className="text-[10px] text-gray-400">{c.created_at && format(new Date(c.created_at), 'MMM d, p')}</span>
                </div>
                <p className="text-xs text-gray-600">{c.text}</p>
              </div>
            </div>
          ))
        }
      </div>
      <div className="px-4 py-3 border-t border-gray-100 flex gap-2">
        <input 
          className="flex-1 text-sm bg-gray-100 rounded-xl px-3 py-2 outline-none" 
          value={text} onChange={e => setText(e.target.value)} placeholder="Comment..." 
        />
        <button onClick={send} disabled={sending} className="bg-black text-white p-2 rounded-xl">
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

const TaskCard = ({ task, canAdvance, onAdvance, isAdvancing, user }: any) => {
  const [showComments, setShowComments] = useState(false);
  const next = NEXT_STATUS[task.status as TaskStatus];

  return (
    <div className="bg-white border border-black/5 rounded-2xl p-4 shadow-sm">
      <div className="flex justify-between items-start mb-2">
        <h4 className="font-bold text-sm">{task.name}</h4>
        {task.deadline && <span className="text-[10px] text-gray-400">{format(new Date(task.deadline), 'MMM d')}</span>}
      </div>
      <p className="text-xs text-gray-500 mb-3">{task.description}</p>
      <div className="flex items-center gap-1.5 mb-3">
        <div className="w-5 h-5 rounded-full bg-gray-200 flex items-center justify-center text-[9px] font-bold">
          {(task.assigned_to_name || 'U').charAt(0).toUpperCase()}
        </div>
        <span className="text-[11px] text-gray-500">{task.assigned_to_name}</span>
      </div>
      <div className="flex items-center justify-between pt-3 border-t border-black/5">
        <button onClick={() => setShowComments(!showComments)} className="text-xs text-gray-400 hover:text-black flex items-center gap-1">
          <MessageSquare className="w-3.5 h-3.5" /> Comments
        </button>
        {canAdvance && next ? (
          <button onClick={onAdvance} disabled={isAdvancing} className="bg-black text-white px-3 py-1 rounded-lg text-xs font-bold flex items-center gap-1">
            {isAdvancing ? <Loader2 className="w-3 h-3 animate-spin" /> : <ChevronRight className="w-3 h-3" />}
            {STATUS_LABEL[task.status as TaskStatus]}
          </button>
        ) : task.status === 'completed' && (
          <span className="text-emerald-600 text-xs font-medium flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5" /> Done</span>
        )}
      </div>
      {showComments && <CommentPanel task={task} user={user} onClose={() => setShowComments(false)} />}
    </div>
  );
};

const CreateTaskModal = ({ isOpen, onClose, projectId, members, onCreated }: any) => {
  const [form, setForm] = useState({ name: '', description: '', assigned_to: '', deadline: '' });
  const [saving, setSaving] = useState(false);
  if (!isOpen) return null;

  const submit = async (e: any) => {
    e.preventDefault();
    setSaving(true);
    try {
      await taskService.create({ ...form, project: Number(projectId), assigned_to: Number(form.assigned_to) });
      toast.success('Task created');
      onCreated();
      onClose();
    } catch (err: any) {
      toast.error('Error creating task');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-3xl w-full max-w-md p-8">
        <h3 className="text-xl font-bold mb-6">New Task</h3>
        <form onSubmit={submit} className="space-y-4">
          <input className="w-full p-3 bg-gray-100 rounded-xl" placeholder="Task Name" required onChange={e => setForm({...form, name: e.target.value})} />
          <textarea className="w-full p-3 bg-gray-100 rounded-xl h-24" placeholder="Description" required onChange={e => setForm({...form, description: e.target.value})} />
          <input type="date" className="w-full p-3 bg-gray-100 rounded-xl" required onChange={e => setForm({...form, deadline: e.target.value})} />
          <select className="w-full p-3 bg-gray-100 rounded-xl" required onChange={e => setForm({...form, assigned_to: e.target.value})}>
            <option value="">Assign To...</option>
            {members.map((m: any) => <option key={m.user} value={m.user}>{m.name}</option>)}
          </select>
          <div className="flex gap-2">
            <button type="button" onClick={onClose} className="flex-1 py-3 bg-gray-100 rounded-xl">Cancel</button>
            <button type="submit" disabled={saving} className="flex-1 py-3 bg-black text-white rounded-xl">Create</button>
          </div>
        </form>
      </div>
    </div>
  );
};

const ProjectDetails = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [project, setProject] = useState<Project | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [members, setMembers] = useState<ProjectMember[]>([]);
  const [allUsers, setAllUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showTeamPanel, setShowTeamPanel] = useState(false);
  const [selectedUsers, setSelectedUsers] = useState<number[]>([]);
  const [teamLead, setTeamLead] = useState<number | null>(null);
  const [showTaskModal, setShowTaskModal] = useState(false);
  const [advancingId, setAdvancingId] = useState<number | null>(null);

  const fetchData = async () => {
    try {
      const [proj, taskList, users, memberList] = await Promise.all([
        projectService.getById(id!),
        taskService.getByProject(id!),
        authService.getUsers(),
        projectService.getMembers(id!),
      ]);
      setProject(proj);
      setTasks(taskList); // taskService now handles the pagination check
      setAllUsers(users);
      setMembers(memberList);
    } catch {
      toast.error('Failed to load project');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, [id]);

  const advanceStatus = async (task: Task) => {
    const next = NEXT_STATUS[task.status];
    if (!next) return;
    setAdvancingId(task.id);
    try {
      await taskService.updateStatus(task.id, { status: next });
      setTasks(prev => prev.map(t => t.id === task.id ? { ...t, status: next } : t));
    } catch {
      toast.error('Status update failed');
    } finally {
      setAdvancingId(null);
    }
  };

  const isTeamLead = members.some(m => m.user === user?.id && m.is_team_lead);
  const isManager = user?.role === 'manager';

  if (loading) return <div className="flex justify-center py-32"><Loader2 className="w-8 h-8 animate-spin text-gray-300" /></div>;

  return (
    <div className="space-y-10 max-w-7xl mx-auto p-6">
      <button onClick={() => navigate('/dashboard')} className="flex items-center gap-2 text-sm text-gray-400 hover:text-black">
        <ArrowLeft className="w-4 h-4" /> Back
      </button>

      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-4xl font-bold mb-2">{project?.name}</h1>
          <p className="text-gray-500">{project?.description}</p>
        </div>
        {isTeamLead && (
          <button onClick={() => setShowTaskModal(true)} className="bg-black text-white px-5 py-2.5 rounded-xl flex items-center gap-2 font-bold text-sm">
            <Plus className="w-4 h-4" /> New Task
          </button>
        )}
      </div>

      <section>
        <h2 className="text-xl font-bold mb-4">Team</h2>
        <div className="flex flex-wrap gap-3">
          {members.map(m => (
            <div key={m.user} className="flex items-center gap-3 px-4 py-3 bg-white border border-black/5 rounded-2xl shadow-sm">
              <div className="w-8 h-8 rounded-full bg-black text-white flex items-center justify-center text-xs font-bold">
                {m.name.charAt(0).toUpperCase()}
              </div>
              <span className="text-sm font-semibold">{m.name} {m.is_team_lead && '(Lead)'}</span>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-xl font-bold mb-4">Task Board</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {COLUMNS.map(col => (
            <div key={col.key} className="rounded-2xl p-4" style={{ background: col.bg }}>
              <div className="flex justify-between items-center mb-4">
                <span className="text-xs font-bold uppercase" style={{ color: col.color }}>{col.label}</span>
                <span className="text-xs font-bold text-gray-400">
                  {tasks.filter(t => t.status === col.key).length}
                </span>
              </div>
              <div className="space-y-3">
                {tasks.filter(t => t.status === col.key).map((task, idx) => (
                  <TaskCard
                    // SAFETY KEY: If task.id is missing, it uses the index
                    key={task.id || `task-${idx}`} 
                    task={task}
                    canAdvance={task.assigned_to === user?.id}
                    onAdvance={() => advanceStatus(task)}
                    isAdvancing={advancingId === task.id}
                    user={user}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      <CreateTaskModal
        isOpen={showTaskModal}
        onClose={() => setShowTaskModal(false)}
        projectId={id}
        members={members}
        onCreated={fetchData}
      />
    </div>
  );
};

export default ProjectDetails;