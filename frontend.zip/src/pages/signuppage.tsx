import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import api from '../services/api';
import { toast } from 'react-hot-toast';

const signuppage = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    role: 'employee', // Default role
  });

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      // Calling your Django Backend: /api/auth/signup/
      await api.post('/auth/signup/', formData);
      toast.success('Account created! Please login.');
      navigate('/login'); // Move to login page after success
    } catch (error: any) {
      toast.error(error.response?.data?.email?.[0] || 'Signup failed');
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-[#F5F5F4]">
      <div className="w-full max-w-md p-8 bg-white shadow-xl rounded-3xl">
        <h2 className="mb-6 text-3xl font-bold text-center">Create Account</h2>
        <form onSubmit={handleSignup} className="space-y-4">
          <input
            type="text"
            placeholder="Full Name"
            className="w-full p-3 bg-gray-100 border-none rounded-xl"
            onChange={(e) => setFormData({...formData, name: e.target.value})}
            required
          />
          <input
            type="email"
            placeholder="Email Address"
            className="w-full p-3 bg-gray-100 border-none rounded-xl"
            onChange={(e) => setFormData({...formData, email: e.target.value})}
            required
          />
          <input
            type="password"
            placeholder="Password"
            className="w-full p-3 bg-gray-100 border-none rounded-xl"
            onChange={(e) => setFormData({...formData, password: e.target.value})}
            required
          />
          <select 
            className="w-full p-3 bg-gray-100 border-none rounded-xl"
            onChange={(e) => setFormData({...formData, role: e.target.value})}
          >
            <option value="employee">Employee</option>
            <option value="manager">Manager</option>
          </select>
          <button className="w-full py-3 font-bold text-white bg-black rounded-xl hover:bg-gray-800">
            Sign Up
          </button>
        </form>
        <p className="mt-4 text-center text-sm">
          Already have an account? <Link label="Login" to="/login" className="font-bold underline">Login here</Link>
        </p>
      </div>
    </div>
  );
};

export default signuppage;